package challenge;

public interface QuoteService {

	Quote getQuote();
	
	Quote getQuoteByActor(String actor);

}
